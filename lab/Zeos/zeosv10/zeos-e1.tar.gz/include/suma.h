#ifndef __SUMA_H__
#define __SUMA_H__

int addAsm(int a, int b);

#endif  /* __SUMA_H__ */
